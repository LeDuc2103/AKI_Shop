-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 02, 2025 at 08:46 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kltn`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `ma_banner` bigint(20) NOT NULL,
  `id_sanpham` bigint(20) NOT NULL,
  `hinh_anh` varchar(250) collate utf8_unicode_ci default NULL,
  `ngay_dang` date default NULL,
  `created_at` timestamp NULL default NULL,
  `update_at` timestamp NULL default NULL,
  PRIMARY KEY  (`ma_banner`),
  KEY `fk_banners_san_pham` (`id_sanpham`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `banners`
--


-- --------------------------------------------------------

--
-- Table structure for table `chitiet_donhang`
--

CREATE TABLE `chitiet_donhang` (
  `id_ctdh` bigint(20) NOT NULL auto_increment,
  `ma_donhang` bigint(20) NOT NULL,
  `id_sanpham` bigint(20) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `don_gia` double NOT NULL,
  PRIMARY KEY  (`id_ctdh`),
  KEY `ma_donhang` (`ma_donhang`),
  KEY `id_sanpham` (`id_sanpham`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `chitiet_donhang`
--


-- --------------------------------------------------------

--
-- Table structure for table `danh_gia`
--

CREATE TABLE `danh_gia` (
  `id_danhgia` bigint(20) NOT NULL,
  `ma_kh` varchar(50) collate utf8_unicode_ci NOT NULL,
  `id_sanpham` bigint(20) NOT NULL,
  `noi_dung` varchar(500) collate utf8_unicode_ci default NULL,
  `ngay_binhluan` date default NULL,
  `created_at` timestamp NULL default NULL,
  `update_at` timestamp NULL default NULL,
  `trang_thai` tinyint(4) default NULL,
  PRIMARY KEY  (`id_danhgia`),
  KEY `fk_danh_gia_san_pham` (`id_sanpham`),
  KEY `fk_danh_gia_khach_hang` (`ma_kh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `danh_gia`
--


-- --------------------------------------------------------

--
-- Table structure for table `danh_muc`
--

CREATE TABLE `danh_muc` (
  `id_danhmuc` bigint(20) NOT NULL,
  `ten_danhmuc` varchar(250) collate utf8_unicode_ci default NULL,
  `created_at` timestamp NULL default NULL,
  `update_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id_danhmuc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `danh_muc`
--


-- --------------------------------------------------------

--
-- Table structure for table `don_hang`
--

CREATE TABLE `don_hang` (
  `ma_donhang` bigint(20) NOT NULL,
  `ten_nguoinhan` varchar(50) collate utf8_unicode_ci NOT NULL,
  `diachi_nhan` varchar(250) collate utf8_unicode_ci NOT NULL,
  `email_nguoinhan` varchar(50) collate utf8_unicode_ci NOT NULL,
  `so_dienthoai` varchar(50) collate utf8_unicode_ci NOT NULL,
  `trangthai_thanhtoan` varchar(50) collate utf8_unicode_ci NOT NULL,
  `phuongthuc_thanhtoan` varchar(50) collate utf8_unicode_ci NOT NULL,
  `thanh_toan` varchar(50) collate utf8_unicode_ci NOT NULL,
  `tien_hang` double NOT NULL,
  `tien_ship` double NOT NULL,
  `tong_tien` double NOT NULL,
  `ma_kh` varchar(50) collate utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `trang_thai` enum('cho_xu_ly','dang_xu_ly','hoan_thanh','huy') collate utf8_unicode_ci default 'cho_xu_ly',
  PRIMARY KEY  (`ma_donhang`),
  KEY `fk_don_hang_khach_hang` (`ma_kh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `don_hang`
--


-- --------------------------------------------------------

--
-- Table structure for table `gio_hang`
--

CREATE TABLE `gio_hang` (
  `id_giohang` bigint(20) NOT NULL,
  `ma_kh` varchar(50) collate utf8_unicode_ci NOT NULL,
  `id_sanpham` bigint(20) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `thanh_tien` double NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id_giohang`),
  UNIQUE KEY `ma_kh` (`ma_kh`),
  KEY `fk_gio_hang_san_pham` (`id_sanpham`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `gio_hang`
--


-- --------------------------------------------------------

--
-- Table structure for table `khach_hang`
--

CREATE TABLE `khach_hang` (
  `ma_kh` varchar(50) collate utf8_unicode_ci NOT NULL,
  `ten_kh` varchar(250) collate utf8_unicode_ci NOT NULL,
  `password` varchar(50) collate utf8_unicode_ci NOT NULL,
  `phone` char(10) collate utf8_unicode_ci NOT NULL,
  `email` varchar(50) collate utf8_unicode_ci NOT NULL,
  `dia_chi` varchar(250) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`ma_kh`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `khach_hang`
--


-- --------------------------------------------------------

--
-- Table structure for table `mau_sac`
--

CREATE TABLE `mau_sac` (
  `ma_mau` bigint(20) NOT NULL,
  `ten_mau` varchar(255) collate utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ma_mau`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `mau_sac`
--


-- --------------------------------------------------------

--
-- Table structure for table `nhan_vien`
--

CREATE TABLE `nhan_vien` (
  `ma_nhanvien` bigint(20) NOT NULL,
  `ho_ten` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(250) collate utf8_unicode_ci default NULL,
  `password` varchar(255) collate utf8_unicode_ci default NULL,
  `phone` varchar(50) collate utf8_unicode_ci default NULL,
  `dia_chi` varchar(255) collate utf8_unicode_ci default NULL,
  `vai_tro` varchar(50) collate utf8_unicode_ci default NULL,
  `created_at` timestamp NULL default NULL,
  `update_at` timestamp NULL default NULL,
  `ma_vaitro` bigint(20) default NULL,
  `id_role` bigint(20) default NULL,
  `trang_thai` enum('active','inactive') collate utf8_unicode_ci default 'active',
  PRIMARY KEY  (`ma_nhanvien`),
  KEY `fk_nhan_vien_vai_tro` (`ma_vaitro`),
  KEY `fk_nhan_vien_role` (`id_role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `nhan_vien`
--


-- --------------------------------------------------------

--
-- Table structure for table `password_forgot`
--

CREATE TABLE `password_forgot` (
  `email` varchar(50) collate utf8_unicode_ci NOT NULL,
  `token` varchar(255) collate utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `update_at` timestamp NOT NULL default '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `password_forgot`
--


-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id_role` bigint(20) NOT NULL,
  `ten_role` varchar(255) collate utf8_unicode_ci NOT NULL,
  `mo_ta` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id_role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `role`
--


-- --------------------------------------------------------

--
-- Table structure for table `san_pham`
--

CREATE TABLE `san_pham` (
  `id_sanpham` bigint(20) NOT NULL,
  `ten_sanpham` varchar(250) collate utf8_unicode_ci default NULL,
  `gia` double default NULL,
  `hinh_anh` varchar(250) collate utf8_unicode_ci default NULL,
  `mau_sac` varchar(250) collate utf8_unicode_ci default NULL,
  `so_luong` int(50) default NULL,
  `mo_ta` varchar(500) collate utf8_unicode_ci NOT NULL,
  `id_danhmuc` bigint(20) NOT NULL,
  `created_at` timestamp NULL default NULL,
  `update_at` timestamp NULL default NULL,
  `ma_km` bigint(20) NOT NULL,
  PRIMARY KEY  (`id_sanpham`),
  KEY `fk_san_pham_danh_muc` (`id_danhmuc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `san_pham`
--


-- --------------------------------------------------------

--
-- Table structure for table `tin_tuc`
--

CREATE TABLE `tin_tuc` (
  `ma_tintuc` bigint(20) NOT NULL,
  `hinh_anh` varchar(250) collate utf8_unicode_ci default NULL,
  `ngay_tao` date default NULL,
  `nguoi_tao` varchar(250) collate utf8_unicode_ci default NULL,
  `noi_dung` varchar(255) collate utf8_unicode_ci default NULL,
  `ma_nhanvien` bigint(20) NOT NULL,
  `tieu_de` text collate utf8_unicode_ci,
  `created_at` timestamp NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `update_at` timestamp NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ma_tintuc`),
  KEY `fk_tin_tuc_nhan_vien` (`ma_nhanvien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tin_tuc`
--


-- --------------------------------------------------------

--
-- Table structure for table `vai_tro`
--

CREATE TABLE `vai_tro` (
  `ma_vaitro` bigint(20) NOT NULL,
  `ten_vaitro` varchar(255) collate utf8_unicode_ci NOT NULL,
  `mota_vaitro` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`ma_vaitro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vai_tro`
--


-- --------------------------------------------------------

--
-- Table structure for table `xuat_kho`
--

CREATE TABLE `xuat_kho` (
  `id_xuat` bigint(20) NOT NULL auto_increment,
  `ma_donhang` bigint(20) NOT NULL,
  `id_sanpham` bigint(20) NOT NULL,
  `so_luong` int(11) NOT NULL,
  `ngay_xuat` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `ma_nhanvien` bigint(20) NOT NULL,
  PRIMARY KEY  (`id_xuat`),
  KEY `fk_xuat_kho_donhang` (`ma_donhang`),
  KEY `fk_xuat_kho_sanpham` (`id_sanpham`),
  KEY `fk_xuat_kho_nhanvien` (`ma_nhanvien`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `xuat_kho`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `banners`
--
ALTER TABLE `banners`
  ADD CONSTRAINT `fk_banners_san_pham` FOREIGN KEY (`id_sanpham`) REFERENCES `san_pham` (`id_sanpham`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `chitiet_donhang`
--
ALTER TABLE `chitiet_donhang`
  ADD CONSTRAINT `chitiet_donhang_ibfk_1` FOREIGN KEY (`ma_donhang`) REFERENCES `don_hang` (`ma_donhang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `chitiet_donhang_ibfk_2` FOREIGN KEY (`id_sanpham`) REFERENCES `san_pham` (`id_sanpham`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `danh_gia`
--
ALTER TABLE `danh_gia`
  ADD CONSTRAINT `fk_danh_gia_khach_hang` FOREIGN KEY (`ma_kh`) REFERENCES `khach_hang` (`ma_kh`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_danh_gia_san_pham` FOREIGN KEY (`id_sanpham`) REFERENCES `san_pham` (`id_sanpham`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `don_hang`
--
ALTER TABLE `don_hang`
  ADD CONSTRAINT `fk_don_hang_khach_hang` FOREIGN KEY (`ma_kh`) REFERENCES `khach_hang` (`ma_kh`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gio_hang`
--
ALTER TABLE `gio_hang`
  ADD CONSTRAINT `fk_gio_hang_san_pham` FOREIGN KEY (`id_sanpham`) REFERENCES `san_pham` (`id_sanpham`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_gio_hang_khach_hang` FOREIGN KEY (`ma_kh`) REFERENCES `khach_hang` (`ma_kh`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD CONSTRAINT `fk_nhan_vien_role` FOREIGN KEY (`id_role`) REFERENCES `role` (`id_role`),
  ADD CONSTRAINT `fk_nhan_vien_vai_tro` FOREIGN KEY (`ma_vaitro`) REFERENCES `vai_tro` (`ma_vaitro`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `san_pham`
--
ALTER TABLE `san_pham`
  ADD CONSTRAINT `fk_san_pham_danh_muc` FOREIGN KEY (`id_danhmuc`) REFERENCES `danh_muc` (`id_danhmuc`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tin_tuc`
--
ALTER TABLE `tin_tuc`
  ADD CONSTRAINT `fk_tin_tuc_nhan_vien` FOREIGN KEY (`ma_nhanvien`) REFERENCES `nhan_vien` (`ma_nhanvien`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `xuat_kho`
--
ALTER TABLE `xuat_kho`
  ADD CONSTRAINT `fk_xuat_kho_donhang` FOREIGN KEY (`ma_donhang`) REFERENCES `don_hang` (`ma_donhang`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_xuat_kho_sanpham` FOREIGN KEY (`id_sanpham`) REFERENCES `san_pham` (`id_sanpham`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_xuat_kho_nhanvien` FOREIGN KEY (`ma_nhanvien`) REFERENCES `nhan_vien` (`ma_nhanvien`) ON DELETE CASCADE ON UPDATE CASCADE;
